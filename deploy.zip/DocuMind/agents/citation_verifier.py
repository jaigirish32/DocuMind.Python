"""
DocuMind/agents/citation_verifier.py

Parses structured LLM output and verifies citations against retrieved chunks.

The LLM is prompted to return JSON with this shape:
{
  "answer": "...",
  "citations": [
    {"chunk_id": "...", "quote": "..."}
  ]
}

This module:
  1. Parses that JSON safely.
  2. Verifies each chunk_id was actually retrieved.
  3. Verifies each quote is a real substring of that chunk.
  4. Flags hallucinated citations.
"""
from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Any

from DocuMind.core.logging.logger import get_logger

logger = get_logger(__name__)


@dataclass
class VerifiedAnswer:
    """
    Result of parsing + verifying an LLM answer.

    - answer:             the natural-language answer the user sees
    - citations_valid:    citations that passed verification
    - citations_invalid:  citations that were fabricated or misquoted
    - source_pages:       unique pages referenced by valid citations
    - parse_failed:       True if JSON parsing failed (fallback used)
    - hallucination_risk: "none" | "low" | "high"
    """
    answer:             str
    citations_valid:    list[dict] = field(default_factory=list)
    citations_invalid:  list[dict] = field(default_factory=list)
    source_pages:       list[int]  = field(default_factory=list)
    parse_failed:       bool       = False
    hallucination_risk: str        = "none"


def parse_and_verify(
    llm_output:       str,
    retrieved_chunks: list[dict],
) -> VerifiedAnswer:
    """
    Main entry point.

    Args:
        llm_output:       raw string returned by the LLM (expected JSON).
        retrieved_chunks: list of chunk dicts from hybrid_search; must contain
                          'chunk_id', 'content' (or 'text'), 'page_number'.

    Returns:
        VerifiedAnswer with answer text, valid/invalid citations, risk level.
    """
    # Step 1 — parse JSON safely
    parsed = _safe_parse_json(llm_output)

    if parsed is None:
        # JSON parsing failed — fall back to treating whole output as the answer
        logger.warning("LLM output was not valid JSON", preview=llm_output[:200])
        return VerifiedAnswer(
            answer             = llm_output,
            parse_failed       = True,
            hallucination_risk = "high",
        )

    answer    = parsed.get("answer", "").strip()
    citations = parsed.get("citations", [])

    if not isinstance(citations, list):
        logger.warning("citations field is not a list", type=type(citations).__name__)
        citations = []

    # Step 2 — build a lookup index of retrieved chunks by chunk_id
    chunk_index = {
        c.get("chunk_id", ""): c
        for c in retrieved_chunks
        if c.get("chunk_id")
    }

    # Step 3 — verify each citation
    valid:   list[dict] = []
    invalid: list[dict] = []

    for citation in citations:
        if not isinstance(citation, dict):
            invalid.append({"reason": "citation is not a dict", "raw": citation})
            continue

        chunk_id = citation.get("chunk_id", "").strip()
        quote    = citation.get("quote", "").strip()

        # Check 1 — does this chunk_id exist in the retrieved chunks?
        if chunk_id not in chunk_index:
            invalid.append({
                "chunk_id": chunk_id,
                "quote":    quote[:80],
                "reason":   "fabricated chunk_id — not in retrieved chunks",
            })
            continue

        # Check 2 — does the quote actually appear in that chunk?
        chunk       = chunk_index[chunk_id]
        chunk_text  = chunk.get("content", "") or chunk.get("text", "")

        if not _quote_appears_in(quote, chunk_text):
            invalid.append({
                "chunk_id": chunk_id,
                "quote":    quote[:80],
                "reason":   "quote not found in chunk content",
            })
            continue

        # Citation passes both checks
        valid.append({
            "chunk_id": chunk_id,
            "page":     chunk.get("page_number", 0),
            "quote":    quote,
        })

    # Step 4 — derive source pages from valid citations only
    source_pages = sorted({c["page"] for c in valid if c["page"]})

    # Step 5 — classify hallucination risk
    risk = _classify_risk(valid, invalid, answer)

    if invalid:
        logger.warning(
            "Some citations failed verification",
            invalid_count = len(invalid),
            valid_count   = len(valid),
            invalid       = invalid,
        )

    return VerifiedAnswer(
        answer             = answer,
        citations_valid    = valid,
        citations_invalid  = invalid,
        source_pages       = source_pages,
        parse_failed       = False,
        hallucination_risk = risk,
    )


# ── helpers ───────────────────────────────────────────────────────────────────

def _safe_parse_json(raw: str) -> dict | None:
    """
    Parse JSON, tolerating common LLM mistakes like wrapping in ```json blocks.
    Returns None if parsing fails completely.
    """
    if not raw or not raw.strip():
        return None

    text = raw.strip()

    # Strip markdown code fences if the LLM added them despite the prompt
    if text.startswith("```"):
        # remove first line (```json or ```) and last line (```)
        lines = text.split("\n")
        if lines[0].startswith("```"):
            lines = lines[1:]
        if lines and lines[-1].strip() == "```":
            lines = lines[:-1]
        text = "\n".join(lines).strip()

    try:
        parsed = json.loads(text)
        if isinstance(parsed, dict):
            return parsed
        logger.warning("JSON parsed but is not a dict", type=type(parsed).__name__)
        return None
    except json.JSONDecodeError as e:
        logger.warning("JSON parse failed", error=str(e))
        return None


def _quote_appears_in(quote: str, chunk_text: str) -> bool:
    """
    Check whether the quote is a substring of the chunk text.
    We normalize whitespace to tolerate line-break differences between
    the chunk (often multi-line) and the LLM's quote (often single-line).
    """
    if not quote or not chunk_text:
        return False

    # Normalize: collapse whitespace, lowercase for case-insensitive match
    def _normalize(s: str) -> str:
        return " ".join(s.split()).lower()

    return _normalize(quote) in _normalize(chunk_text)


def _classify_risk(
    valid:   list[dict],
    invalid: list[dict],
    answer:  str,
) -> str:
    """
    Rough heuristic:
    - high:  any invalid citations, OR answer is non-trivial but has no citations
    - low:   everything validates but the answer is short / no strong claims
    - none:  all citations valid and answer is substantive
    """
    refusal_phrases = [
        "not available in the retrieved documents",
        "i don't have that information",
    ]
    is_refusal = any(p in answer.lower() for p in refusal_phrases)

    if is_refusal:
        return "none"

    if invalid:
        return "high"

    if not valid and answer:
        return "high"   # claims without citations

    return "none"